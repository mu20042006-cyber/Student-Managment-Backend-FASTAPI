import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from motor.motor_asyncio import AsyncIOMotorClient
from unittest.mock import patch, AsyncMock, MagicMock

from app.main import app
from app.core import database as db_module


@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"


@pytest_asyncio.fixture(scope="function")
async def async_client():
    """Provide an async test client with a mocked MongoDB."""
    mock_db = MagicMock()

    # Helper to build async find mocks
    def _make_cursor(docs):
        class AsyncCursor:
            def __init__(self, items):
                self._items = iter(items)
            def skip(self, n): return self
            def limit(self, n): return self
            def __aiter__(self): return self
            async def __anext__(self):
                try:
                    return next(self._items)
                except StopIteration:
                    raise StopAsyncIteration
        return AsyncCursor(docs)

    mock_users = AsyncMock()
    mock_students = AsyncMock()

    mock_db.__getitem__ = lambda self, key: {
        "users": mock_users,
        "students": mock_students,
    }.get(key, AsyncMock())

    with patch.object(db_module, "client", MagicMock()):
        with patch("app.core.database.get_db", return_value=mock_db):
            async with AsyncClient(
                transport=ASGITransport(app=app), base_url="http://test"
            ) as client:
                yield client, mock_users, mock_students
