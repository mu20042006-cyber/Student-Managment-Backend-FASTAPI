import pytest
from unittest.mock import AsyncMock, patch
from bson import ObjectId
from app.core.auth_handler import hash_password


@pytest.mark.anyio
async def test_health_endpoint(async_client):
    client, _, _ = async_client
    response = await client.get("/monitor/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


@pytest.mark.anyio
async def test_root_endpoint(async_client):
    client, _, _ = async_client
    response = await client.get("/")
    assert response.status_code == 200
    assert "Student Management API" in response.json()["message"]


@pytest.mark.anyio
async def test_register_success(async_client):
    client, mock_users, mock_students = async_client

    mock_users.find_one = AsyncMock(return_value=None)
    mock_students.find_one = AsyncMock(return_value=None)
    mock_users.insert_one = AsyncMock(return_value=AsyncMock(inserted_id=ObjectId()))
    mock_students.insert_one = AsyncMock(return_value=AsyncMock(inserted_id=ObjectId()))

    response = await client.post(
        "/auth/register",
        json={
            "username": "testuser",
            "password": "password123",
            "name": "Test User",
            "email": "test@example.com",
            "department": "CS",
        },
    )
    assert response.status_code == 201
    assert response.json()["message"] == "Student registered successfully"


@pytest.mark.anyio
async def test_register_duplicate_username(async_client):
    client, mock_users, _ = async_client

    mock_users.find_one = AsyncMock(return_value={"username": "testuser"})

    response = await client.post(
        "/auth/register",
        json={
            "username": "testuser",
            "password": "password123",
            "name": "Test User",
            "email": "test2@example.com",
        },
    )
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"]


@pytest.mark.anyio
async def test_login_success(async_client):
    client, mock_users, _ = async_client

    user_id = ObjectId()
    mock_users.find_one = AsyncMock(
        return_value={
            "_id": user_id,
            "username": "testuser",
            "password": hash_password("password123"),
            "role": "student",
        }
    )

    response = await client.post(
        "/auth/login",
        data={"username": "testuser", "password": "password123"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["role"] == "student"


@pytest.mark.anyio
async def test_login_wrong_password(async_client):
    client, mock_users, _ = async_client

    mock_users.find_one = AsyncMock(
        return_value={
            "_id": ObjectId(),
            "username": "testuser",
            "password": hash_password("correctpassword"),
            "role": "student",
        }
    )

    response = await client.post(
        "/auth/login",
        data={"username": "testuser", "password": "wrongpassword"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert response.status_code == 401


@pytest.mark.anyio
async def test_me_requires_auth(async_client):
    client, _, _ = async_client
    response = await client.get("/auth/me")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_me_with_valid_token(async_client):
    client, mock_users, _ = async_client

    from app.core.auth_handler import create_access_token
    token = create_access_token({"sub": "testuser", "role": "student"})

    user_id = ObjectId()
    mock_users.find_one = AsyncMock(
        return_value={"_id": user_id, "username": "testuser", "role": "student"}
    )

    response = await client.get(
        "/auth/me", headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
    assert response.json()["username"] == "testuser"
