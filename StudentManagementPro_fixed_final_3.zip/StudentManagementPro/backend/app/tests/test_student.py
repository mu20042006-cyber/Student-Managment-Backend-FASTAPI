import pytest
from unittest.mock import AsyncMock
from bson import ObjectId
from app.core.auth_handler import create_access_token, hash_password
from app.models.models import student_from_doc


def make_student_doc(user_id=None):
    uid = user_id or ObjectId()
    return {
        "_id": ObjectId(),
        "name": "Ahmed Ali",
        "email": "ahmed@example.com",
        "department": "CS",
        "math": 85.0,
        "programming": 90.0,
        "database": 80.0,
        "gpa": 3.0,
        "user_id": uid,
    }


def admin_token():
    return create_access_token({"sub": "admin", "role": "admin"})


def student_token():
    return create_access_token({"sub": "student1", "role": "student"})


@pytest.mark.anyio
async def test_list_students_requires_auth(async_client):
    client, _, _ = async_client
    response = await client.get("/students/")
    assert response.status_code == 401


@pytest.mark.anyio
async def test_list_students_authenticated(async_client):
    client, mock_users, mock_students = async_client

    user_id = ObjectId()
    mock_users.find_one = AsyncMock(
        return_value={"_id": user_id, "username": "admin", "role": "admin"}
    )

    class AsyncCursor:
        def __init__(self): self._data = [make_student_doc(user_id)]
        def skip(self, n): return self
        def limit(self, n): return self
        def __aiter__(self): return iter(self._data).__aiter__()

    mock_students.find = lambda q: AsyncCursor()
    mock_students.count_documents = AsyncMock(return_value=1)

    response = await client.get(
        "/students/",
        headers={"Authorization": f"Bearer {admin_token()}"},
    )
    assert response.status_code == 200
    body = response.json()
    assert "students" in body
    assert body["total"] == 1


@pytest.mark.anyio
async def test_get_student_not_found(async_client):
    client, mock_users, mock_students = async_client

    user_id = ObjectId()
    mock_users.find_one = AsyncMock(
        return_value={"_id": user_id, "username": "admin", "role": "admin"}
    )
    mock_students.find_one = AsyncMock(return_value=None)

    fake_id = str(ObjectId())
    response = await client.get(
        f"/students/{fake_id}",
        headers={"Authorization": f"Bearer {admin_token()}"},
    )
    assert response.status_code == 404


@pytest.mark.anyio
async def test_delete_student_admin_only(async_client):
    client, mock_users, mock_students = async_client

    user_id = ObjectId()
    # Student trying to delete
    mock_users.find_one = AsyncMock(
        return_value={"_id": user_id, "username": "student1", "role": "student"}
    )

    fake_id = str(ObjectId())
    response = await client.delete(
        f"/students/{fake_id}",
        headers={"Authorization": f"Bearer {student_token()}"},
    )
    assert response.status_code == 403


@pytest.mark.anyio
async def test_gpa_calculation():
    from app.services.gpa_service import calculate_gpa
    assert calculate_gpa(95, 92, 91) == 4.0
    assert calculate_gpa(85, 82, 80) == 3.0
    assert calculate_gpa(75, 70, 72) == 2.0
    assert calculate_gpa(60, 65, 62) == 1.0
    assert calculate_gpa(40, 50, 45) == 0.0
    assert calculate_gpa(None, None, None) is None
    assert calculate_gpa(90, None, None) == 4.0
